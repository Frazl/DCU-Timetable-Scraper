import bs4dcu

test = bs4dcu.run("Thu")
test = bs4dcu.beautify(test)